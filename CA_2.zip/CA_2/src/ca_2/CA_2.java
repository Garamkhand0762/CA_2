/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ca_2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author HP
 */
 
import java.io.*;
import java.util.*;

public class CA_2{
    private List<Employee> employees;
    

    public CA_2() {
        employees = new ArrayList<>();
        loadEmployeeDataFromFile("applicants_form.txt");
    }

    private void loadEmployeeDataFromFile(String filename) {
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line = "\\Users\\HP\\OneDrive\\Documents\\NetBeansProjects\\CA_2\\src\\ca_2\\Applicants_Form.txt";
            while ((line = reader.readLine()) != null) {
                // Expecting format:
                // firstName,lastName,gender,email,salary,department,jobTitle,company
                String[] tokens = line.split(",");
                if (tokens.length == 8) {
                    String firstName = tokens[0];
                    String lastName = tokens[1];
                    String gender = tokens[2];
                    String email = tokens[3];
                    double salary = Double.parseDouble(tokens[4]);
                    DepartmentType department = DepartmentType.valueOf(tokens[5].toUpperCase().replace(" ", "_"));
                    String jobTitle = tokens[6];
                    String company = tokens[7];

                    Employee e = new Employee(firstName, lastName, gender, email, salary, department, jobTitle, company);
                    employees.add(e);
                }
            }
            System.out.println("Loaded " + employees.size() + " employees from file.");
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }

    // Placeholder for future menu interaction
    public void displayAllEmployees() {
        for (Employee e : employees) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        CA_2 menu = new CA_2();
        menu.displayAllEmployees();
// loadEmployeeDataFromFile("Applicants_Form");
        
    }
}

         

    

