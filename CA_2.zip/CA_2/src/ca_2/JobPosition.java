/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ca_2;

/**
 *
 * @author HP
 */
public enum JobPosition {
    SOFTWARE_ENGINEER,
    DATA_ANALYST,
    SYSTEM_ADMIN,
    TECH_SUPPORT,
    PROJECT_MANAGER
}

