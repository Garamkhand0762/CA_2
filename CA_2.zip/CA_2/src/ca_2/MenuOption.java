/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ca_2;

/**
 *
 * @author HP
 */

    public enum MenuOption {
    ADD_EMPLOYEE,
    DISPLAY_ALL,
    SORT_BY_NAME,
    SORT_BY_SALARY,
    SEARCH_BY_NAME,
    EXIT
}

